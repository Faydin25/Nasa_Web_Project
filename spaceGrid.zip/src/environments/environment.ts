// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    battleLions : {
        apiKey: "AIzaSyD9qn4N1vsdnjoFxiWwAUlIU8DFaiM_iq0",
        authDomain: "battalions-app.firebaseapp.com",
        projectId: "battalions-app",
        storageBucket: "battalions-app.appspot.com",
        messagingSenderId: "105432735391",
        appId: "1:105432735391:web:dfdd407272161cc1958caa",
        measurementId: "G-2YZT5SZFFJ"
      },
     // region:''
      // ritimus : {
      //   apiKey: "AIzaSyAtX1KmO10iF6eXW14i_XCg-pTtymHiNfM",
      //   authDomain: "ritimus-2.firebaseapp.com",
      //   projectId: "ritimus-2",
      //   storageBucket: "ritimus-2.appspot.com",
      //   messagingSenderId: "266710559210",
      //   appId: "1:266710559210:web:903aa12342af1282276a93",
      //   measurementId: "G-RKF3SZCG37"
      // },
      ritimus : {
        apiKey: "AIzaSyAMy9lYDzS09L-4Bv_DSChKXTcyWvUH8cA",
  authDomain: "ozurluwebsite.firebaseapp.com",
  projectId: "ozurluwebsite",
  storageBucket: "ozurluwebsite.appspot.com",
  messagingSenderId: "404089082456",
  appId: "1:404089082456:web:beaa2a8cf6968dd28eb02d"
      }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
