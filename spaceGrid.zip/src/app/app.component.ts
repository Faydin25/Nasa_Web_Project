import { Component } from '@angular/core';



import "devextreme/localization/globalize/number";
import "devextreme/localization/globalize/date";
import "devextreme/localization/globalize/currency";
import "devextreme/localization/globalize/message";


import trMessages from "devextreme/localization/messages/tr.json";
import enMessages from "devextreme/localization/messages/en.json";
import supplemental from "devextreme-cldr-data/supplemental.json";;
import trCldrData from "devextreme-cldr-data/tr.json";
import enCldrData from "devextreme-cldr-data/en.json";


import Globalize from "globalize";
import config  from "devextreme/core/config";
import { AuthService } from './core/auth/auth.service';
import { UserService } from './core/user/user.service';
import { environment } from 'environments/environment';

declare var gapi: any;


@Component({
    selector   : 'app-root',
    templateUrl: './app.component.html',
    styleUrls  : ['./app.component.scss']
})
export class AppComponent
{
    /**
     * Constructor
     */
    constructor(
        private userService:UserService,
        private authService:AuthService
    )
    {
       // debugger
        Globalize.load(
            supplemental, trCldrData,enCldrData
        );
  
        Globalize.loadMessages(trMessages);
      //  var langMessages: any = await   import("devextreme/localization/messages/" + lang + ".json");
        Globalize.loadMessages(enMessages);
        Globalize.locale('tr') 
        
        let dxConfig = config()

        dxConfig.editorStylingMode ='outlined'
       // config(dxConfig)
// debugger
       if (authService.accessToken) {
        userService.getData(authService.accessToken)
        
       
    }
}


}
