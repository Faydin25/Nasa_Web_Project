import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PermittedDirective } from 'app/core/Utils/Directives/Permitted.directive';
import { TranslocoCoreModule } from 'app/core/transloco/transloco.module';
import { TimestamptoDatePipe } from 'app/core/Utils/Pipes/TimestampToDate/TimestampToDate.pipe';




@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule ,
        TranslocoCoreModule,
        
        
    ],
    declarations:[
        PermittedDirective,
        TimestamptoDatePipe
    ],
  
    exports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule,
        PermittedDirective,
        TranslocoCoreModule,
        TimestamptoDatePipe
       
    ]
})
export class SharedModule
{
}
