import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RitimUsOptionGroupComponent } from './ritimUs-option-group.component';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  imports: [
    CommonModule,
    MatCheckboxModule
  ],
  declarations: [RitimUsOptionGroupComponent],
  exports:[
    RitimUsOptionGroupComponent
  ]
})
export class RitimUsOptionGroupModule { }
