import { AfterViewInit, Component, ContentChildren, EventEmitter, Inject, Input, OnChanges, OnInit, Optional, Output, QueryList, SimpleChanges, ViewChild, ViewChildren, ViewEncapsulation } from '@angular/core';
import { MatOptgroup, MatOption, MAT_OPTGROUP } from '@angular/material/core';

@Component({
  selector: 'ritimUs-optgroup',
  templateUrl: './ritimUs-option-group.component.html',
  styleUrls: ['./ritimUs-option-group.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RitimUsOptionGroupComponent extends MatOptgroup implements OnInit  {
 
  @Input('roleTypeId') role
  @Output() selectedGroupChange = new EventEmitter()
  @ContentChildren(MatOption) mat_options:QueryList<MatOption>


  options:MatOption[]
  indeterminate = false
  selectedOptionCount = 0
  checked = false

  constructor(
  ) {
    super();
    
  }

  ngAfterViewInit(): void {

    this.options = this.mat_options.toArray()


    this.options.forEach(t=> {

      t.onSelectionChange.subscribe(data => {
        
        if (data.source.selected) {
          this.selectedOptionCount++
        }else{
          this.selectedOptionCount--
          
        }
        //debugger
        if (this.selectedOptionCount > 0) {
          this.indeterminate = true
        }else if (this.selectedOptionCount == 0) {
          this.indeterminate = false
          this.checked = false
          
        }

        if (this.options.length == this.selectedOptionCount) {
          this.indeterminate = false
          this.checked = true
        }
     
      
      })

    })

    
    //this.options.every( t=> t.onSelectionChange.subscribe(e =>  this.indeterminate = true))

  //  debugger

    let a = 3


    // this.mat_options.changes.subscribe(data => //console.log(data))
  }

  ngOnInit() {
  
  }

  change(e){
   // //console.log(e)
    if (e.checked) {
      this.options.forEach(t => t.select())
    }else{
      this.options.forEach(t => t.deselect())

    }
    this.selectedGroupChange.emit({
      e ,
     roleTypeId : this.role

    })
  }

}
