export const userStatus = [
  { id: 1, name: 'Üye olması bekleniyor' },
  { id: 2, name: 'Üye oldu' },
  { id: 3, name: 'Üye kurumsal sisteme giriş yapamaz' },
]

export const  intelligences =[
  {id:0 , name: 'Uzamsal / Görsel'},
  {id:1 , name: 'Matıksal / Matematiksel'},
  {id:2 , name: 'Dil Bilimsel / Sözel'},
  {id:3 , name: 'Armonik / Ritmik'},
  {id:4 , name: 'Bedensel / Kinestetik'},

]

export const   problemSolvingSkills = [
  {id: 0 , name: "Analitik"},
  {id: 1 , name: "Yaratıcı / İnovatif"},
  {id: 2 , name: "Adaptif / Esnek"},
  {id: 3 , name: "Öğrenmeye Dayalı"},
  {id: 4 , name: "Yanal Düşünme"}

]
export const months = [
  "Ocak",
  "Şubat",
  'Mart',
  "Nisan",
  "Mayıs",
  "Haziran",
  "Temmuz",
  "Ağustos",
  "Eylül",
  "Ekim",
  "Kasım",
  "Aralık"
]

export const guardPerms = [
  "NTF-000",
  "MYH-000",
  "SUP-000",
  "SUP-100",
  "SUP-200",
  "CAL-000",
  "CAL-001",
  "CAL-002",
  "MYD-000",
  "PRF-000",
  "PRT-000",
  "PRT-100",
  "PRT-001",
  "PRT-002",
  "PRT-003",
  "IFB-000",
  "SEC-100"
]

export const schoolCategories = [
  {id: 1 , name: "Özel"},
  {id: 2 , name: "Kurumsal"},
  {id: 3 , name: "Kamu"},
  //{id: 1 , name: "Özel"},

]