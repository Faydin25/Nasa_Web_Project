/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PermittedDirective } from './Permitted.directive';

describe('Directive: Permitted', () => {
  it('should create an instance', () => {
    const directive = new PermittedDirective();
    expect(directive).toBeTruthy();
  });
});
