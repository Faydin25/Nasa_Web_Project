/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FindByPermsPipe } from './FindByPerms.pipe';

describe('Pipe: FindByPermse', () => {
  it('create an instance', () => {
    let pipe = new FindByPermsPipe();
    expect(pipe).toBeTruthy();
  });
});
