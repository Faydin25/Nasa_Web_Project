import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'FindByPerms'
})
export class FindByPermsPipe implements PipeTransform {

  transform(value: string, source:any[]): any {
   
    //debugger
    let desc = source.find(t => t.perm == value).description

    return desc

  }

  
}
