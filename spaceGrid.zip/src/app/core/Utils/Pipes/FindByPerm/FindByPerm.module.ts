import { NgModule } from '@angular/core';
import { FindByPermsPipe } from './FindByPerms.pipe';



@NgModule({

  declarations: [	FindByPermsPipe
   ],
  exports: [FindByPermsPipe]
})
export class FindByPermModule { }
