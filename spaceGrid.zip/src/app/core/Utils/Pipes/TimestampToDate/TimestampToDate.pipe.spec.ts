/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TimestampToDatePipe } from './TimestampToDate.pipe';

describe('Pipe: TimestampToDatee', () => {
  it('create an instance', () => {
    let pipe = new TimestampToDatePipe();
    expect(pipe).toBeTruthy();
  });
});
