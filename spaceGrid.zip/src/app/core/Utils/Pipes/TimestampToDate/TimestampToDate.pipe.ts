import { Pipe, PipeTransform } from '@angular/core';

import { Timestamp } from '@angular/fire/firestore';


@Pipe({
  name: 'TimestamptoDate'
})
export class TimestamptoDatePipe implements PipeTransform {

  transform(value:any, args?: any): Date {

  //debugger
    if(value instanceof Timestamp){
      return value.toDate()
    }
    if( typeof value === 'string' ){
      let e = new Date( value)
      return e || new Date()
    }
    if (value._nanoseconds) {
      var epoch = new Date(0)
      epoch.setSeconds(value._seconds)
      return epoch
    }
    return value ;
  }

}
