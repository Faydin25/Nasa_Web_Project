import { ChangeDetectorRef, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, ReplaySubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Navigation } from 'app/core/navigation/navigation.types';
import { UserService } from '../user/user.service';
import { clone, cloneDeep } from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class NavigationService {
    private _navigation: ReplaySubject<Navigation> = new ReplaySubject<Navigation>(1);

    /**
     * Constructor
     */
    constructor(
        private _httpClient: HttpClient,
        private userService: UserService,

    ) {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for navigation
     */
    get navigation$(): Observable<Navigation> {
        return this._navigation.asObservable();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Get all navigation data
     */
    get(): Observable<Navigation> {
        return this._httpClient.get<Navigation>('api/common/navigation').pipe(
            tap((navigation) => {

                this.userService.user.subscribe(user => {
                    if (!user) {
                        return
                    }
                    let _navigation = cloneDeep(navigation);
                 
                    navigation.default.forEach((item , index) => {
                  //      debugger

                        let _index = _navigation.default.findIndex(t => t.id == item.id) 
                        
                
                        if (item.meta) {
                            if (!user.perms.includes(item.meta)) {
                                _navigation.default.splice(_index, 1);
                            }
                        }
                        if (item.children) {
                            
                            item.children.forEach((child,childIndex) => {
                                let _childIndex = _navigation.default[_index].children.findIndex(t => t.id == child.id)
                                let _child = _navigation.default[_index].children[_childIndex]
                                if (_child.meta) {
                                    if (!user.perms.includes(_child.meta)) {
                                        _navigation.default[_index].children.splice(_childIndex , 1)
                                        if (_navigation.default[_index].children.length == 0) {
                                            _navigation.default.splice(_index, 1);
                                        }
                                    }
                                }

                            })


                        }


                    }) 

                    // _navigation.default.forEach((item, index) => {
                    // //    debugger

                    //     if (item.meta) {

                    //         if (!user.perms.includes(item.meta)) {
                    //             _navigation.default.splice(_navigation.default.findIndex(t => t == item), 1);
                    //         }
                    //     } 
                    //     if (item.children) {
                    //         item.children.forEach((child, childIndex) => {
                    //             if (child.meta) {
                    //                 if (!user.perms.includes(child.meta)) {
                    //                     debugger
                    //                     let a = _navigation.default.findIndex(t => t == item)
                    //                     console.log(index)
                    //                    _navigation.default[_navigation.default.findIndex(t => t.id == item.id)].children.splice(_navigation.default[index].children.findIndex(t => t.id === child.id), 1);

                    //                     if (_navigation.default[index].children.length == 0) {
                    //                         _navigation.default.splice(index, 1);
                    //                     }
                    //                 }
                    //             }
                    //         })
                    //     }

             

                    // })
               //     debugger
                    this._navigation.next(_navigation);

       
                })

            })
        );
    }
}
