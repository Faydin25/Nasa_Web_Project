import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SchoolService {

  selectedSchool = new BehaviorSubject(null);

  constructor(
    private db: AngularFirestore,
    private storage:AngularFireStorage
  ) { 
  this.selectedSchool.subscribe(school => school == null ? localStorage.removeItem("selectedSchool") : '')

  }


  getSchools(schoolIds) {


    let idArr = []
    
    while (schoolIds.length > 10) {

      let arr = schoolIds.splice(10)

      idArr = [
        ...idArr,
        ...arr

      ]
    }

    if (schoolIds.length <= 10) {

      idArr = [
        ...idArr,
        ...schoolIds
      ]
    }

    let promise = new Promise(async (resolve, reject) => {

      let schools = []

      try {
        for (let index = 0; index < idArr.length; index++) {
          const element = idArr[index];

          let school = (await this.db.collection("schools").doc(element).get().toPromise()).data()

          schools.push(school)
        }
        resolve(schools)
      } catch (error) {
        reject(error)
      }


    })


    return promise

  }

  getSchool(schoolId){

    let observable = new Observable<any>(subscriber => {

      this.db.collection("schools").doc(schoolId).get().subscribe(res => {

        let school:any = res.data()

        this.db.collection("classrooms").ref.where("schoolId" , "==" , schoolId).get().then(response => {

          school.classrooms = response.docs.map(t => t.data())

          subscriber.next(school)


        })



      })

    })

    return observable
  }

 async addAnnouncement(schoolId,announcement:{banner,externalLink,message,title,updateDate}, bannerFile:File){


    if (bannerFile) {
      
    let imageRef = await    this.storage.upload("announcements/" + schoolId + '/' + bannerFile.name , bannerFile)


      announcement.banner = await imageRef.ref.getDownloadURL()


    }


 return   this.db.collection('schools').doc(schoolId).update({
      announcement: announcement
    })



  }

}
