import { DecimalPipe, PercentPipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { cloneDeep } from 'lodash';
import { BehaviorSubject, Subject } from 'rxjs';


class AnalyticalData {

  intelDiffBalance = []
   problemDiffBalance = []

   intelScoreBalance = []
   problemScoreBalance = []

  intelCompare: any
   problemCompare: any
  scoreCompare: any
   diffCompare: any


 

}



@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  selectedPlayer = new BehaviorSubject(null)

  constructor(
    private db: AngularFirestore
  ) {

    this.selectedPlayer.subscribe(player => player == null ? localStorage.removeItem("selectedPlayer") : '')
  }



  getPlayers(userId) {
    return this.db.collection("players").ref.where("authUserID", "==", userId).where("studentInfo.schoolID", "!=", "").get()
  }

  getNonCorporatePlayers(userId) {
    return this.db.collection("players").ref.where("authUserID", "==", userId).where("studentInfo.schoolID", "==", "").get()
  }

  getPlayerAnalytic(player) {

    let decimalPipe = new DecimalPipe("en")
    console.log(player)

    let analyticData = new AnalyticalData()

    let lastMibdans = cloneDeep(player.mibdansLog).pop()
    let mibdans = cloneDeep(player.mibdans)
    
    let intelObj = this.createGraphData()
    let intelScoreObj = this.createGraphData()
    for(let i = 0 ; i < mibdans.intelligences.length ; i++ ){

     // debugger
      let intel = mibdans.intelligences[i] 
      let lastIntel = {totalRawPoints:0}

      if (lastMibdans) {
        lastIntel = lastMibdans.intelligences[i]
      }
     
      intelObj.data.push(decimalPipe.transform(intel.difficulty))
      intelScoreObj.data.push(

          intel.totalRawPoints - lastIntel.totalRawPoints

      )



    }

    analyticData.intelDiffBalance.push(intelObj)
    analyticData.intelScoreBalance.push(intelScoreObj)

    let problemObj = this.createGraphData()
    let problemScoreObj = this.createGraphData()

    for(let i = 0 ; i < mibdans.problemSolvingSkills.length ; i++){

      let problem = mibdans.problemSolvingSkills[i] 
      let lastProblem = {totalRawPoints:0}

      if (lastMibdans) {
        lastProblem = lastMibdans.problemSolvingSkills[i]
      }
      problemObj.data.push(decimalPipe.transform( problem.difficulty))

      problemScoreObj.data.push(

        problem.totalRawPoints - lastProblem.totalRawPoints

    )

    }

    analyticData.problemDiffBalance.push(problemObj)
    analyticData.problemScoreBalance.push(problemScoreObj)
  

    return analyticData
    
  }

  getPlayerCompareAnalytic(_player , _playerAnalytic:AnalyticalData){

    let decimalPipe = new DecimalPipe("en")

    let promise= new Promise((resolve ,reject) => {
      this.db.collection("classrooms").doc(_player.studentInfo.classroomID).get().subscribe(async res => {

        let students = res.get("students")
  
       let players:any = await (await this.db.collection("players").ref.where("id" , "in" , students).get()).docs.map(t => t.data())
  
       
       
       let calculateblePlayers = []
       
       for(let player of players ){
         
         
         let playerAnalytic = this.getPlayerAnalytic(player)
         
         let obj = { 
           player: player,
           intelDiff: playerAnalytic.intelDiffBalance.pop(),
           solvingDiff: playerAnalytic.problemDiffBalance.pop()
          }
          
          calculateblePlayers.push(obj)
          
          
        }
        //debugger
        
        _playerAnalytic.intelDiffBalance[0].name = _player.studentInfo.fullname
        _playerAnalytic.problemDiffBalance[0].name = _player.studentInfo.fullname

        let returnData = {
          
          intelDiff: [
            _playerAnalytic.intelDiffBalance[0],
            this.createGraphData('Sınıf')
          ],
          solvingDiff:[
            _playerAnalytic.problemDiffBalance[0],
            this.createGraphData('Sınıf')

          ]
          
          
        }
        
     
 

        for(let i = 0 ; i < calculateblePlayers[0].intelDiff.data.length; i++){

          let avgData = 0

          for (let j = 0; j < calculateblePlayers.length; j++) {
            const element = calculateblePlayers[j];

           avgData +=  Number( element.intelDiff.data[i] )


            
          }

          avgData /= calculateblePlayers[0].intelDiff.data.length

          returnData.intelDiff[1].data.push(decimalPipe.transform( avgData))


        }

        for(let i = 0 ; i < calculateblePlayers[0].solvingDiff.data.length; i++){

          let avgData = 0

          for (let j = 0; j < calculateblePlayers.length; j++) {
            const element = calculateblePlayers[j];

           avgData +=  Number( element.solvingDiff.data[i] )


            
          }

          avgData /= calculateblePlayers[0].solvingDiff.data.length

          returnData.solvingDiff[1].data.push(decimalPipe.transform( avgData))


        }
       // debugger  
        console.log(calculateblePlayers)

        resolve(returnData)
        
  
  
      })
  
    })
    
  
    return promise



  }


  private createGraphData(name = 'Değer'){

    return Object.assign({} ,  {name: name , data: []}) 

  }

}
