import { Component, HostListener, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertType } from '@fuse/components/alert';
import { AuthService } from 'app/core/auth/auth.service';
import { _FirebaseError } from 'app/core/Utils/Enums/FirebaseErrors.enum';
import { LovService } from 'app/core/Utils/lov.service';
import { FirebaseError } from 'firebase/app';
import { FacebookAuthProvider, GoogleAuthProvider, OAuthProvider } from "firebase/auth"



@Component({
    selector: 'auth-sign-in',
    templateUrl: './sign-in.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations
})
export class AuthSignInComponent implements OnInit {
    @ViewChild('signInNgForm') signInNgForm: NgForm;


    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: ''
    };
    signInForm: FormGroup;
    showAlert: boolean = false;
    corporateLogin = false
    guardLogin = false
    forgetPassword = false
    forgettedEmail = ""
    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _authService: AuthService,
        private _formBuilder: FormBuilder,
        private _router: Router,
        private auth: AngularFireAuth,
        private snackbar:MatSnackBar,
        private matDialogRef:MatDialogRef<AuthSignInComponent>

    ) {
        let url = this._router.url

        if (url.includes("corporate")) {
            this.corporateLogin = true
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {

       
        // Create the form
        this.signInForm = this._formBuilder.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', Validators.required],
          
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign in
     */
    async signIn() {

        
        // Return if the form is invalid
        if (this.signInForm.invalid) {
            return;
        }

        // Disable the form
        this.signInForm.disable();

        // Hide the alert
        this.showAlert = false;


        const data = this.signInForm.value
        

        

      

        this.auth.signInWithEmailAndPassword(data.email, data.password).then(async res => {

            this.signInForm.enable();

            // Reset the form
            this.signInNgForm.resetForm();
            console.log("başarılı" ,res)
          
            this.close()
        

        }).catch((err: FirebaseError) => {

            console.log("hata",err)
            debugger
            this.signInForm.enable();

            // Reset the form
            this.signInNgForm.resetForm();
            switch (err.code) {
                case _FirebaseError.notFound:
                    this.alert = {
                        type: 'error',
                        message: 'Bu emaille kayıtlı kullanıcı bulunamadı.'
                    };
                    break;

                case _FirebaseError.wrongPassword:
                    this.alert = {
                        type: 'error',
                        message: 'Şifreniz yanlış. Yada sosyal medya ile giriş yaptınız'
                    };
                    break;

                default:
                    break;
            }



            // Show the alert
            this.showAlert = true;

        })

 
    }


    sendResetPassword(){
        this.auth.sendPasswordResetEmail(this.forgettedEmail).then(() => {
            
            this.snackbar.open("Gönderildi")
            this.close()
        
        })
    }

    signInWithGoogle() {
        this.popupLogin(new GoogleAuthProvider().addScope("https://www.googleapis.com/auth/calendar")).then(async t => {
            
            let a = t
            let result = await this._authService.checkUser(t.user.email, this.corporateLogin)
            debugger
            if (typeof result == 'string') {
                this.showAlert = true;
                this.alert = {
                    type: 'error',
                    message: result
                };
                this.signInForm.enable();

                // Reset the form
                this.signInNgForm.resetForm();
                return;
            }
            if (!(result as any).navigate) {

                if (this.corporateLogin) {
                    localStorage.setItem("userType", "2")
                    return this._router.navigateByUrl("/corporate/sign-up")
                }

                return this._router.navigateByUrl("/sign-up")
            }


            localStorage.setItem("userType", this.corporateLogin ? "2" : "1")

          await     this._authService.signIn(t.user.uid)

            const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/signed-in-redirect';

            // Navigate to the redirect url
            this._router.navigateByUrl(redirectURL);

        }).catch(err => console.log(err))
    }

    signInWithFacebook() {
        this.popupLogin(new FacebookAuthProvider().addScope("https://www.googleapis.com/auth/calendar")).then(async t => {
            debugger
            let a = t
            let result = await this._authService.checkUser(t.user.email, this.corporateLogin)
            if (typeof result == 'string') {
                this.showAlert = true;
                this.alert = {
                    type: 'error',
                    message: result
                };
                this.signInForm.enable();

                // Reset the form
                this.signInNgForm.resetForm();
                return;
            }
            if (!(result as any).navigate) {

                if (this.corporateLogin) {
                    localStorage.setItem("userType", "2")
                    return this._router.navigateByUrl("/corporate/sign-up")
                }

                return this._router.navigateByUrl("/sign-up")
            }


            localStorage.setItem("userType", this.corporateLogin ? "2" : "1")
            
            await     this._authService.signIn(t.user.uid)

            const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/signed-in-redirect';

            // Navigate to the redirect url
            this._router.navigateByUrl(redirectURL);


        }).catch(err => console.log(err))
    }

    signInWithApple() {
        this.popupLogin(new OAuthProvider('apple.com')).then(async t => {
            debugger
            let a = t

            let result = await this._authService.checkUser(t.user.email, this.corporateLogin)
            if (typeof result == 'string') {
                this.showAlert = true;
                this.alert = {
                    type: 'error',
                    message: result
                };
                this.signInForm.enable();

                // Reset the form
                this.signInNgForm.resetForm();
                return;
            }

            if (!(result as any).navigate) {

                if (this.corporateLogin) {
                    localStorage.setItem("userType", "2")
                    return this._router.navigateByUrl("/corporate/sign-up")
                }

                return this._router.navigateByUrl("/sign-up")
            }


            localStorage.setItem("userType", this.corporateLogin ? "2" : "1")
            await     this._authService.signIn(t.user.uid)

            const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/signed-in-redirect';

            // Navigate to the redirect url
            this._router.navigateByUrl(redirectURL);

        }).catch(err => console.log(err))
    }

    popupLogin(provider) {
        return this.auth.signInWithPopup(provider)
    }

    goToUrl(url){
        location.href = url
    }
    
    close(){
        this.matDialogRef.close()
    }

}
