import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AbstractControl, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertType } from '@fuse/components/alert';
import { FuseValidators } from '@fuse/validators';
import { AuthService } from 'app/core/auth/auth.service';
import { _FirebaseError } from 'app/core/Utils/Enums/FirebaseErrors.enum';

import notify from 'devextreme/ui/notify';

@Component({
    selector: 'auth-sign-up',
    templateUrl: './sign-up.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations
})
export class AuthSignUpComponent implements OnInit {
    @ViewChild('signUpNgForm') signUpNgForm: NgForm;

    alert: { type: FuseAlertType; message: string , data?:any } = {
        type: 'success',
        message: '',
        data:{}
    };
    guardSignUpForm: FormGroup;
    corporateSignUpForm: FormGroup;
    passwordForm: FormGroup;
    showAlert: boolean = false;

    codeVerified = false
    codeCheck = false
    schools
    classrooms
    codes
    players
    disabled = false
    userId

    selectedSchool

    corporateSignUp = false
    notLogin = false
    createUser = false

    singignUp = false

    /**
     * Constructor
     */
    constructor(
        private _authService: AuthService,
        private auth: AngularFireAuth,
        private _formBuilder: FormBuilder,
        private _router: Router,
        private activatedRoute: ActivatedRoute,
    ) {

        let url = this._router.url

        if (url.includes("corporate")) {
            this.corporateSignUp = true
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {



        if (this.corporateSignUp) {
            this.buildCorporateForm()
        } else {
            this.buildGuardForm()
        }

        this.auth.user.subscribe(res => {

            if(this.singignUp) return

            debugger

             if (!res && this.corporateSignUp) {
                this.buildPasswordForm() 
                this.createUser = true
             }
            this.activatedRoute.params.subscribe(data => {

                if (data.code) {
                    console.log("hi")
                    this.buildCorporateForm({ name: res?.displayName, email: res?.email, code: data.code })
                } else {
                    if (!res && !this.corporateSignUp) {
                        this.alert = {
                            type: 'error',
                            message: "Giriş yapmanız gerekmektedir."
                        };

                        // Show the alert
                        this.showAlert = true;
                        this.notLogin = true
                    } else {
                        console.log('user')
                        console.log(res)
                        this.userId = res.uid

                        if (this.corporateSignUp) {
                            this.buildCorporateForm()
                        } else {
                            this.buildGuardForm({ name: res.displayName, email: res.email })
                
                        }


                    }
                }



            })



        })




    }

    buildGuardForm(data?) {

        data = data || {}

        this.guardSignUpForm = this._formBuilder.group({
            fullname: [data.name, Validators.required],
            email: [data.email, [Validators.required, Validators.email]],
            studentID: ['', Validators.required],
            schoolID: ['', Validators.required],
            classroomID: ['' , Validators.required],
            playerID: ['', Validators.required],
            citizenshipID: ["", [Validators.required , Validators.maxLength(11)]],
            code: ['', Validators.maxLength(10)],
            agreements: ['', Validators.requiredTrue]
        },

        );


        this.guardSignUpForm.controls['citizenshipID'].valueChanges.subscribe((val:string) => {

            if(val.length == 11){
                let strArr = val.split('')

                let lastNumber =  Number( strArr.pop())

                let total = 0

                strArr.forEach(t => total += Number(t))

                if ((total % 10) != lastNumber ) {
                    
                    this.guardSignUpForm.controls['citizenshipID'].setErrors({notCitizen:true})

                }



            }

        })

    }

    buildCorporateForm(data?) {

        data = data || {}
        // debugger
        this.corporateSignUpForm = this._formBuilder.group({
            fullname: [data.name, Validators.required],
            email: [data.email, [Validators.required, Validators.email]],
            phone: ['', Validators.required],
            code: [data.code, Validators.maxLength(10)],
            agreements: ['', Validators.requiredTrue]
        },

        );

    
    }

    buildPasswordForm(){
        this.passwordForm = this._formBuilder.group({
            password       : ['', Validators.required],
            passwordConfirm: ['', Validators.required]
        },
        {
            validators: FuseValidators.mustMatch('password', 'passwordConfirm')
        })
    }



   


    checkCorporateCode() {

        this.showAlert = false
        debugger

        let emailControl = this.corporateSignUpForm.get("email")
        let codeControl = this.corporateSignUpForm.get("code")

        if (emailControl.invalid && codeControl.invalid) {
            return
        }

        this.corporateSignUpForm.disable()

        this._authService.checkCorporateCode(codeControl.value, emailControl.value).then(res => {


            this.corporateSignUpForm.enable();
            if (res.empty) {
                this.alert = {
                    type: 'error',
                    message: "Kod yanlış yada emaille kod uyuşmuyor"
                };

                // Show the alert
                this.showAlert = true;

            } else {
             
                this.selectedSchool = res.data.schoolID
                this.codeVerified = true
             
            }



        })


    }
    //     this.corporateSignUpForm.controls['code'].valueChanges.subscribe((val: string) => {

    //         debugger
    //         let a = this.corporateSignUpForm.get('email').valid
    //         if (val.length == 8 && a) {
    //             this.codeCheck = true

    //             this._authService.checkCorporateCode(val, this.corporateSignUpForm.value.email).then(result => {

    //                 if (result) {
    //                     this.alert = {
    //                         type: 'error',
    //                         message: "Kod bulunamadı veya Yanlış Kod"
    //                     };
    //                     this.codeCheck = false
    //                     // Show the alert
    //                     this.showAlert = true;
    //                 } else {
    //                     this.codeVerified = true
    //                 }

    //             })
    //         }

    //     })
    // } else {



    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign up
     */
    async signUp() {

        this.showAlert = false;
debugger

        if (this.corporateSignUp) {

            debugger

            if (this.corporateSignUpForm.invalid ||(  this.passwordForm?.invalid)) {
                return;
            }

            // this._authService.checkCodeGetSchool()

            if (this.createUser) {
                try {
                    this.singignUp = true
                  this.userId  =  await this._authService.createUser(this.corporateSignUpForm.value.email , this.passwordForm.value.password , this.selectedSchool)
                    
                } catch (err) {
                    if (err.code == _FirebaseError.alreadyUse){
                        this.alert = {
                            type: 'error',
                            message: err.message,
                            data: {login:true}
                        };
        
                        // Show the alert
                        this.showAlert = true;
                        this.notLogin = true 

                    }else{
                        this.alert = {
                            type: 'error',
                            message: err.message
                        };
        
                        // Show the alert
                        this.showAlert = true;
                    }
                }
            }


            this._authService.corporateSignUp(this.corporateSignUpForm.value.email , this.corporateSignUpForm.value.phone , this.userId).then(() => {
            
            notify("Yetkili Kaydınız Gerçekleşmiştir. Lütfen Giriş Yapınız" ,"success")
            this._router.navigateByUrl("/corporate/sign-in")


            }   )

        } else {
            if (this.guardSignUpForm.invalid) {
                return;
            }

            // Disable the form
            this.guardSignUpForm.disable();

            // Hide the alert

            let code = this.codes.find(t => t.schoolID == this.selectedSchool.id)

            let result = await this._authService.checkSelectedSchoolCodeIsUsed(code.id)

            if ((result)) {
                this.alert = {
                    type: 'error',
                    message: 'Kod daha önce kullanılmış'
                };

                // Show the alert
                this.showAlert = true;
                return
            }
            // Sign up
            this._authService.signUp(this.guardSignUpForm.value, this.selectedSchool, this.userId, code)
                .then(
                    (response) => {

                        // Navigate to the confirmation required page
            notify("Kaydınız Gerçekleşmiştir. Lütfen Giriş Yapınız" , "success")
                        
                        this._router.navigateByUrl("/sign-in")

                    }).catch(response => {

                        // Re-enable the form
                        this.guardSignUpForm.enable();

                        // Reset the form
                        this.signUpNgForm.resetForm();

                        // Set the alert
                        this.alert = {
                            type: 'error',
                            message: 'Something went wrong, please try again.'
                        };

                        // Show the alert
                        this.showAlert = true;
                    }
                    );
        }

        // Do nothing if the form is invalid

    }

    goToUrl(url){
        location.href = url
    }

}
