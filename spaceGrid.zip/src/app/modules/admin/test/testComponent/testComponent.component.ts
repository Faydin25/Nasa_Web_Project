import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testComponent',
  templateUrl: './testComponent.component.html',
  styleUrls: ['./testComponent.component.scss']
})
export class TestComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
