import { Component, Input, OnInit } from '@angular/core';
import { SchoolService } from 'app/core/school/school.service';

@Component({
  selector: 'schoolSelector',
  templateUrl: './schoolSelector.component.html',
  styleUrls: ['./schoolSelector.component.scss']
})
export class SchoolSelectorComponent implements OnInit {

  @Input('perm') perm
  school
  schools
  user
  getSchools = false

  constructor(
    private schoolService:SchoolService
  ) {
    this.user = JSON.parse(localStorage.getItem("user"))
    // debugger
   this.getSchools = !this.user.perms.includes("SEC-100")
   }

  ngOnInit() {
    console.log(this.perm)
debugger

    if (this.getSchools) {
      this.schoolService.getSchools(this.user.schoolIDs).then((res:any[]) => {

        this.schools = res
  
        if (res.length == 1) {
          this.school = res[0]
          this.setSelectedSchool(this.school);
        }
  
      })
    }
    
  }

  private setSelectedSchool(school) {
    this.schoolService.selectedSchool.next(school);
    localStorage.setItem("selectedSchool", JSON.stringify( school));
  }

  selectionChange(e){
    this.setSelectedSchool(e.value)
  }
}
