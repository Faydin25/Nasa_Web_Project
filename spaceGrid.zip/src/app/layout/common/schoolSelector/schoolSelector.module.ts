import { NgModule } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { SharedModule } from 'app/shared/shared.module';
import { SchoolSelectorComponent } from './schoolSelector.component';

@NgModule({
  imports: [
    SharedModule,
    MatFormFieldModule,
    MatSelectModule
  ],
  declarations: [SchoolSelectorComponent],
  exports:[
    SchoolSelectorComponent
  ]
})
export class SchoolSelectorModule { }
