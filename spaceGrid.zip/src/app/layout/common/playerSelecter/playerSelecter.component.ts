import { Component, Input, OnInit } from '@angular/core';
import { PlayerService } from 'app/core/player/player.service';

@Component({
  selector: 'playerSelecter',
  templateUrl: './playerSelecter.component.html',
  styleUrls: ['./playerSelecter.component.scss']
})
export class PlayerSelecterComponent implements OnInit {

  @Input('perm') perm
  user
  players:any[]
  player
  getPlayers = false
  constructor(
    private playerService:PlayerService
  ) { 
    
    this.user = JSON.parse( localStorage.getItem("user"))
    this.getPlayers = this.user.perms.includes("SEC-100")
  }

  ngOnInit() {
    

    if (this.getPlayers) {
      this.playerService.getPlayers(this.user.id).then((players) => {
        console.log(players)
        this.players = players.docs.map(t => t.data())
        if (this.players.length == 1) {
          this.player = this.players[0]
          this.setSelectedPlayer(this.player)
          
        }
      } )
    }


  }
  selectionChange(e){
    console.log(e)
    this.setSelectedPlayer(e.value);
  }


  private setSelectedPlayer(player: any) {
    localStorage.setItem("selectedPlayer", JSON.stringify(player));
    this.playerService.selectedPlayer.next(player);
  }
}
