import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlayerSelecterComponent } from './playerSelecter.component';
import { SharedModule } from 'app/shared/shared.module';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';

@NgModule({
  imports: [
    SharedModule,
    MatFormFieldModule,
    MatSelectModule
  ],
  declarations: [PlayerSelecterComponent],
  exports: [PlayerSelecterComponent]
})
export class PlayerSelecterModule { }
