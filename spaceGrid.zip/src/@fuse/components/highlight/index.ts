export * from '@fuse/components/highlight/public-api';
